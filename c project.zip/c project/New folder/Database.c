/*********************************************************************
Name of the module	:Database.c
Date of creation	:5/7/2020 
Author of module	:Komal Bankar

Description of module:
This module contains the all functions defination of of the Database component.  

Different function supported in this module:
void read_file_db(FILE *fp);                   Function to read the data from excel file.
void write_file_db( FILE *fp);                 Function to write the updated data back to the excel file.
void add_structure(char str[],int field_count);Function to store the details of employee into struct employee.
struct node* search_details(int id);           Function to search the details of employee.
void add_to_db(struct employee e1);            Function to store  data into database.

Revision/Modification History:
Added 	Database.c		Komal Bankar 	5/7/2020.

*****************************************************************************************************************************************************************/

#include "TSIndia.h"
/**************************************************************************************************************************
Function Name:void add_structure(char str[],int);
Description:This Function call from read_file_db()function.It is used to store the details of employee into struct employee structure.
****************************************************************************************************************************/

struct node *head_node=0,*first_node=0,*temp_node=0,*prev_node=0,*next_node=0;
struct employee t1={0,0,0,0,0,0,0,0,0,0};

void add_structure(char str[],int field_count)
{
	char string[10]="NA";
	int i=0;
	struct date dmy={0,0,0};
		if(field_count==1)
		{
			t1.emp_id=atoi(str);
			
		}
		if(field_count==2)
		{
			strcpy(t1.emp_name,str);
			
		}
		 if(field_count==3)
		{
			strcpy(t1.emp_email_id,str);
		}
		if(field_count==4)
		{
			strcpy(t1.band,str);
		}

		if(field_count==5)
		{
			for(i=0;str[i]>='0' && str[i]<='9';i++)
				dmy.date=dmy.date*10+str[i]-48;
			     t1.emp_doj.date=dmy.date;
		    
			for(i=i+1;str[i]>='0' && str[i]<='9';i++)
				dmy.month=dmy.month*10+str[i]-48;
			     t1.emp_doj.month=dmy.month;
		    
			
			for(i=i+1;str[i]>='0' && str[i]<='9';i++)
				dmy.year=dmy.year*10+str[i]-48;
			     t1.emp_doj.year=dmy.year;
		    
		
		}
		
		if(field_count==6)
		{ 
	   strcpy(t1.ph_no,str);
	   
		  
		}
		
		if(field_count==7)
		{
			strcpy(t1.manager_name,str);
		
		
		}
		if(field_count==8)
		{
			strcpy(t1.tech_area,str);
     	}
		if(field_count==9)
		{
			strcpy(t1.project_info,str);		
		}
		if(field_count==10)
		{
			if(strcmp(str,string)==0)
			{
				t1.emp_doe.date=0;
				t1.emp_doe.month=0;
				t1.emp_doe.year=0;
			}
			
		}
		fflush(stdin);
}

/**************************************************************************************************************************
Function Name:void add_to_db(struct employee);
Description:This Function call from read_file_db()function.It is used to store the details of employee into Database.
****************************************************************************************************************************/

void add_to_db(struct employee e1)
{   
	temp_node=(struct node*)malloc(sizeof(struct node));
	temp_node->data.emp_id=e1.emp_id;
	strcpy(temp_node->data.emp_name,e1.emp_name);
    strcpy(temp_node->data.emp_email_id,e1.emp_email_id);
	strcpy(temp_node->data.band,e1.band);
	temp_node->data.emp_doj.date=e1.emp_doj.date;
    temp_node->data.emp_doj.month=e1.emp_doj.month;
    temp_node->data.emp_doj.year=e1.emp_doj.year;
    strcpy(temp_node->data.ph_no,e1.ph_no);
	
	strcpy(temp_node->data.manager_name,e1.manager_name);

	strcpy(temp_node->data.tech_area,e1.tech_area);
	strcpy(temp_node->data.project_info,e1.project_info);
	temp_node->data.emp_doe.month=e1.emp_doe.month;
    temp_node->data.emp_doe.year=e1.emp_doe.year;
    temp_node->data.emp_doe.date=e1.emp_doe.date;

	temp_node->next=0;
	
	if(first_node==0)
	{
		first_node=temp_node;
	}
	else
	{
		head_node->next=temp_node;
		
	}
	temp_node->next=0;
	head_node=temp_node;
	fflush(stdin);
	
}

	
/**************************************************************************************************************************
Function Name:struct node* search_details(int);
Description:This Function call from view and delete component.It is used to search the details of employee and it returns the address of 
particular employee.
****************************************************************************************************************************/

struct node* search_details(int id)
{temp_node=first_node;
	while(temp_node!=0)
	{
		if(temp_node->data.emp_id==id)
		{
			return temp_node;
		}
         temp_node=temp_node->next;
	}
return NULL;
}


/**************************************************************************************************************************
Function Name:void read_file_db(FILE*);
Description:It is used to read the details of employee from the excel file.
****************************************************************************************************************************/
	
void read_file_db(FILE *fp)
{	
	char buf[1024]="";
	char str[100]="";
	int row_count=0;
	int field_count=0;
	

	while(fgets(buf,1024,fp))
	{ 
        field_count=0;
		row_count++;
	
    if(row_count==1)
	  {
		continue;
		}
	
		char *field=strtok(buf,",");
		while(field)
		{   
		    strcpy(str,field);
		    field_count++;
			add_structure(str,field_count);	
			field=strtok(NULL,",");
		}
	
	  add_to_db(t1);
	
    }

	
	fclose(fp);


}
/**************************************************************************************************************************
Function Name:void write_file_db(FILE*);
Description:It is used to write the details of employe into the excel file.
****************************************************************************************************************************/
void write_file_db( FILE *fp)
{       char ch='/';
        
	    char str1[10]="NA";
	    temp_node=first_node;
		while(temp_node!=0)
		{ 
	        fprintf(fp,"%d ,",temp_node->data.emp_id);
			fprintf(fp,"%s ,",temp_node->data.emp_name);
			fprintf(fp,"%s ,",temp_node->data.emp_email_id);
			fprintf(fp,"%s ,",temp_node->data.band);
			fprintf(fp,"%d %c %d %c %d ,",temp_node->data.emp_doj.date,ch,temp_node->data.emp_doj.month,ch,temp_node->data.emp_doj.year);
			
			
		    fprintf(fp,"%s ,",temp_node->data.ph_no);
			
			
		   	fprintf(fp,"%s ,",temp_node->data.manager_name);
			fprintf(fp,"%s ,",temp_node->data.tech_area);
			fprintf(fp,"%s ,",temp_node->data.project_info);
			
			if(temp_node->data.emp_doe.date==0)
			{
			fprintf(fp,"%s \n",str1);
			}
			else
			{
			fprintf(fp,"%d %c %d %c %d \n",temp_node->data.emp_doe.date,ch,temp_node->data.emp_doe.month,ch,temp_node->data.emp_doe.year);
	       
			}
	        temp_node=temp_node->next;
			
		}
		
		
}

