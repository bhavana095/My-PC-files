/*********************************************************************
Name of the module	:delete.h
Date of creation	:06-07-2020
Author of module	:Sreekesh Kulakarni
Description of module:
This module contains all the functions declaration that are used in delete Component.



Revision/Modification History:
Added 		delete.h		Sreekesh Kulakarni			06-07-2020
**************************************************************************/


#ifndef __delete_h__
#define __delete_h__


void delete_details(void);
int check_date(int,int,int);
#endif