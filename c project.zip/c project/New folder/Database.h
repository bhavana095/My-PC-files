/*******************************************************************************************************************************
Name of the module	:Database.h
Date of creation	:5/7/2020 
Author of module	:Komal Bankar

Description of module:
This module contains all the declarations of  functions which is defined in Database.c.

Revision/Modification History:
Added 	Database.h 		Komal Bankar 	5/7/2020.

*****************************************************************************************************************************************************************/





#ifndef __Database_h__
#define __Database_h__



void read_file_db(FILE* fp);
void add_structure(char str[],int);
struct node* search_details(int);
void write_file_db(FILE *fp);
void add_to_db(struct employee);

#endif