/**********************************************************************************************************************
Name of the module		: main.c
Date of creation 		: 3/7/2020 
Author of module 		: Komal Bankar

Description of module-
This module contains the all functions defination of of the Main component.

Different function supported in the module:
void main_component();          Function to call other component.
void print_menu();      		Function  to display main menu.
void add_component();           Function to call add component.
void print_add_menu();  		Function  to display add  menu.
void view_component();          Function to call view component.
void print_view_menu(); 	    Function  to display view menu
void modify_component();        Function to call modify component
void print_modify_menu();  		Function  to display modify menu.
void print_delete_menu();  	    Function  to display delete menu.
void delete_component();        Function to call delete component.
Revision/modification History
Added   	      main.c      Komal Bankar		3-07-2020

*************************************************************************************************************************/


#include"TSIndia.h"

/**************************************************************************************************************************
Function Name:void main_menu(void);
Description:This is the main function which calls all other component.
****************************************************************************************************************************/
void main_component()
{
	
	char choice;
	while(1)
	{
	print_main_menu();
	printf("Enter your choice\n");
	fflush(stdin);
	scanf(" %c",&choice);
	fflush(stdin);
	switch(choice)
	{
		case '1':add_component();
		break;
		case '2':view_component();
		break;
		case '3':modify_component();
		break;
		case '4':delete_component();
		break;
	    case '*':
		return ;
        default :printf("Wrong choice is entered please enter correct choice\n");
        break;
	}
	}
}
/*****************************************************************************************************************************
Function Name:void print_main_menu(void);
Description:This function is called in main_component()function.It is used to display main menu on stdout.
******************************************************************************************************************************/
void print_main_menu()
{
	printf("******************************************************************************************\n");
	printf("***                           Reporting Structure                                      ***\n");
	printf("******************************************************************************************\n");
	printf("\n");
	printf("                                 Main Menu                                                 \n");
	printf("\n");
	printf("                                 1. ADD                                                    \n");
	printf("                                 2. VIEW                                                   \n");
	printf("                                 3. MODIFY                      \n");
	printf("                                 4. DELETE                        \n");
	printf("                                 *. Exit                                            \n");
}
/*****************************************************************************************************************************
Function Name:void add_component(void);
Description:This function is called from main_component() function.It is used to call add component for enter the details 
of employee.
******************************************************************************************************************************/

void add_component()
{
	char add_choice='0';
	int flag=0;
	while(1)
	{
	print_add_menu();
	printf("Enter your choice\n");
	fflush(stdin);
	scanf(" %c",&add_choice);
	fflush(stdin);
	switch(add_choice)
	{
		case '1':add_details();
		break;
		case '*':
	   flag=1;
		break ;
       default :printf("Wrong choice is entered please enter correct choice\n");
        break;
	}
	if(flag==1)
		break;
	}
}

/*****************************************************************************************************************************
Function Name:void view_component(void);
Description:This functon is called in main_component()function.It is used to call view component for get to know 
employee is existing or not.
******************************************************************************************************************************/
void view_component()
{
	char view_choice='0';
	int flag=0;
	while(1)
	{
	print_view_menu();
	printf("Enter your choice\n");
	fflush(stdin);
	scanf(" %c",&view_choice);
	fflush(stdin);
	switch(view_choice)
	{
		case '1':view_details();
		break;
		case '*':
	   flag=1;
		break ;
       default :printf("Wrong choice is entered please enter correct choice\n");
        break;
	}
	if(flag==1)
		break;
	}
}
/*****************************************************************************************************************************
Function Name:void modify_component(void);
Description:This functon is called in main_component()function.It is used to call modify component for modify the details of
employee if needed.
*****************************************************************************************************************************/
void modify_component()
{
	char modify_choice='0';
	int flag=0;
	while(1)
	{
	print_modify_menu();
	printf("Enter your choice\n");
	fflush(stdin);
	scanf(" %c",&modify_choice);
	fflush(stdin);
	switch(modify_choice)
	{
		case '1':modify_details();
		break;
		case '*':
	   flag=1;
		break ;
       default :printf("Wrong choice is entered please enter correct choice\n");
        break;
	}
	if(flag==1)
		break;
	}
}
/*****************************************************************************************************************************
Function Name:void delete_component(void);
Description:This functon is called in main_component()function.It is used to call delete component.
******************************************************************************************************************************/
void delete_component()
{
	char delete_choice='0';
	int flag=0;
	while(1)
	{
	print_delete_menu();
	printf("Enter your choice\n");
	fflush(stdin);
	scanf(" %c",&delete_choice);
	fflush(stdin);
	switch(delete_choice)
	{
		case '1':delete_details();
		break;
		case '*':
	    flag=1;
		break ;
        default :printf("Wrong choice is entered please enter correct choice\n");
        break;
	}
	if(flag==1)
		break;
	}
}
/*****************************************************************************************************************************
Function Name:void print_add_menu(void);
Description:Display add menu on stdout
******************************************************************************************************************************/

void print_add_menu()
{
	printf("******************************************************************************************\n");
	printf("***                           Reporting Structure                                      ***\n");
	printf("******************************************************************************************\n");
	printf("\n");
	printf("                                 Add Menu                                                 \n");
	printf("\n");
	printf("                                 1. Enter details                                                        \n");
	printf("                                 *. Back to Main Menu                                                    \n");
}

/*****************************************************************************************************************************
Function Name:void print_view_menu(void);
Description:This function is called in view_component()function.It is used to display view menu on stdout
******************************************************************************************************************************/
void print_view_menu()
{
	printf("******************************************************************************************\n");
	printf("***                           Reporting Structure                                      ***\n");
	printf("******************************************************************************************\n");
	printf("\n");
	printf("                                 View Menu                                                 \n");
	printf("\n");
	printf("                                 1. View details                                                        \n");
	printf("                                 *. Back to Main Menu                                                    \n");
}

/*****************************************************************************************************************************
Function Name:void print_modify_menu(void);
Description:This function is called in main_component()function.It is used to display modify menu on stdout.
******************************************************************************************************************************/
void print_modify_menu()
{
	printf("******************************************************************************************\n");
	printf("***                           Reporting Structure                                       ***\n");
	printf("******************************************************************************************\n");
	printf("\n");
	printf("                                 Modify Menu                                                 \n");
	printf("\n");
	printf("                                 1. Modify details                                                        \n");
	printf("                                 *. Back to Main Menu                                                    \n");
}
/*****************************************************************************************************************************
Function Name:void print_delete_menu(void);
Description:This function is called in main_component()function.It is used to display delete menu on stdout
******************************************************************************************************************************/
void print_delete_menu()
{
	printf("******************************************************************************************\n");
	printf("***                           Reporting Structure                                       ***\n");
	printf("******************************************************************************************\n");
	printf("\n");
	printf("                                 Delete Menu                                                 \n");
	printf("\n");
	printf("                                 1. Delete details                                                        \n");
	printf("                                 *. Back to Main Menu                                                    \n");
}



