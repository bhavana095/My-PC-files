/******************************************************************************************************************************
Name of the module	:TSIndia.h
Date of creation	:7/7/2020 
Author of module	:Bankar Komal C
Description of module:
This module contains the Global Datatypes and includes all other header files that are required for Reporting Structure 

Global Datatypes Used:

struct employee{};	this structure holds the details of employee like emp_id,emp_name,emp_email_id,band,emp_doj,ph_no,manager_name,project_info,tech_area,emp_doe.
struct node{}; 	    this structure used for linked list to add the details of employee into database.
struct date{};      this structure holds the details of the date of joining and date of existing.

Revision/Modification History:
Added 		Tstel.h 		Komal Bankar		7-07-2020
*******************************************************************************************************************************/


#ifndef __TSIndia_h__
#define __TSIndia_h__
#include<stdio.h>
#include<stdlib.h>
#include<string.h>


struct date{
		int date;
		int month;
		int year;
};
struct employee
{
	unsigned long int emp_id;
	char emp_name[80];
	char emp_email_id[80];
	char band[10];
	char manager_name[80];
	char tech_area[40];
	char project_info[20];
	char ph_no[16];
	struct date emp_doj,emp_doe;
};


struct node
{   
    struct employee data;
	struct node *next;
};

#include"Database.h"
#include"main.h"
#include"add.h"
#include "view.h"
#include "modify.h"
#include "delete.h"

#endif