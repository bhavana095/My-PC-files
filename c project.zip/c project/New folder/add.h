/*********************************************************************
Name of the module	:view.h
Date of creation	:03/07/2020
Author of module	:Bhavana Srimayi Gudipati
Description of module:
This module contains function declarations which used  in add Component.


Revision/Modification History:
Added 		add.h		G.Bhavana Srimayi			03-07-2020
**************************************************************************/


#ifndef __add_h__
#define __add_h__


void add_details(void);
void email(void);

#endif