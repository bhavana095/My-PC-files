/*********************************************************************
Name of the module	:modify.h
Date of creation	:03-07-2020
Author of module	:Sreekesh Kulakarni
Description of module:
This module contains all the functions declaration that are used in Modify Component.



Revision/Modification History:
Added 		modify.h		Sreekesh Kulakarni			03-07-2020
**************************************************************************/


#ifndef __modify_h__
#define __modify_h__


void modify_details(void);

#endif