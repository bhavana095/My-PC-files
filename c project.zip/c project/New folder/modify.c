/*********************************************************************
Name of the module	:modify.c
Date of creation	:03-07-2020
Author of module	:Sreekesh Kulakarni
Description of module:
This module contains all the functions that are used in Modify Component.

Different function supported in the module:
void modify_details(void);      Function to modify the details of employee.

Revision/Modification History:
Added 		modify.c 		Sreekesh Kulakarni			03-07-2020
**************************************************************************/
#include"TSIndia.h"
/**************************************************************************************************************************
Function Name:void modify_details(void);
Description:It is used to modify the details of employee.
****************************************************************************************************************************/
void modify_details()

{
int emp_id,count=0;
char temp[16]="";
	
struct node *ptr=NULL;
	
char opt='0';
	
printf("Enter the Employee id:");
	
scanf("%d",&emp_id);


ptr = search_details(emp_id);
	
if(ptr!=NULL)
	
{

		printf("Displaying the details which can be updated.\n");
		printf("1.Name:%s\n",ptr->data.emp_name);
		printf("2.Band:%s\n",ptr->data.band);
		printf("3.Phone number:%s\n",ptr->data.ph_no);
		printf("4.Manager:%s\n",ptr->data.manager_name);
		printf("5.Technical Area:%s\n",ptr->data.tech_area);
		printf("6.Project Info:%s\n",ptr->data.project_info);
		printf("Enter the choice(1,2,3,4,5,6):");
		fflush(stdin);
		scanf(" %c",&opt);
		//fflush(stdin);
		switch(opt)
		{
			case '1':
			printf("Enter name:\n");
			scanf("%s",ptr->data.emp_name);
			break;
			case '2':
			printf("Enter Band:\n");
			scanf("%s",ptr->data.band);
			break;
			case '3':
			while(1)
			{
				
			printf("Enter the 10 digit Phone Number:\n");
			scanf("%s",temp);
			if(temp[0]=='0')
			{
				printf("Invalid phone number::Phone number cannot start with zero\n");
				continue;
			}
			else
			{	
			strcpy(ptr->data.ph_no,temp);
			break;
			}	
			}
		/*while (temp! =0) 
					{
        					temp /= 10;    
        					++count;
    				}
				if(count==10)
				{
					break;
				}
				else
					printf("Invalid Phone number\n");
			}*/
			break;
			case '4':
			printf("Enter Manager's name:\n");
			scanf("%s",ptr->data.manager_name);
			break;
			case '5':
			printf("Enter Technical area:\n");
			scanf("%s",ptr->data.tech_area);
			break;
			case '6':
			printf("Enter Project information:\n");
			scanf("%s",ptr->data.project_info);
			break;
			default:
			printf("Not a valid option.\n");
			break;
		}
	}
	else
	{
		printf("Not found.Entered Employee id is invalid\n");
}
}
