/*********************************************************************
Name of the module	:add.c
Date of creation	:03-07-2020
Author of module	:Bhavana Srimayi Gudipati
Description of module:
This module contains function definition of Add Component.

Different function supported in the module:
void add_details(void); 		add the details of employee to Databese component.


Revision/Modification History:
Added 		add.c 		G.Bhavana Srimayi			03-07-2020
**************************************************************************/

#include"TSIndia.h"
/**************************************************************************************************************************
Function Name:void add_details(void)
Description:It is used to add details of employee .
****************************************************************************************************************************/


void add_details(){
	struct employee e1={0};
	struct date d1={0};
	int count=0,date=0,month=0,year=0,valid=0,len=0;
	char emp_ph_no[16]="";
	while(1){
	printf("enter Employee ID: ");
	scanf("%d",&e1.emp_id);
	if(e1.emp_id==0){
		e1.emp_id/=10;
		++count;
	}
	else if(count==7)
		break;
	//continue
	else
		printf("Enter valid employee ID\n");
	}
	
	
	printf("enter Employee name: ");
	scanf(" %[^\n]s",e1.emp_name);

	printf("enter employee Band: ");
	scanf(" %[^\n]s",e1.band);
	
	
	email();
	
    while(1)
	{
	printf("enter Date of Joining of Employee (dd-mm-yyyy)\n");
	printf(" enter date(dd): \n");
	scanf("%d",&date);
	printf("enter month(mm): \n");
	scanf("%d",&month);
	printf("enter year(yyyy): \n");
	scanf("%d",&year);
    valid=check_date(date,month,year);
	if(valid==0)
	{
		printf("Entered date is Invalid please valid one\n");
		continue;
	
	}
	else
	{
		e1.emp_doj.date=date;
		e1.emp_doj.month=month;
		e1.emp_doe.year=year;
		break;
	}
	}
    while(1)
	{
		printf("Enter the 10 digit Phone Number:\n");
		scanf("%s",emp_ph_no);
		len=strlen(emp_ph_no);
        if(len<10 || len >16)
		     {
				printf("Invalid phone number\n");
				continue;
			}	
		 if(emp_ph_no[0]=='0')
			{
				printf("Invalid phone number::Phone number cannot start with zero\n");
				continue;
			}
			else
			{
				
			strcpy(e1.ph_no,emp_ph_no);
			break;
			}	
	}
	printf("enter manager name: ");
	scanf(" %[^\n]s",e1.manager_name);
	
	printf("enter tech area of Employee: ");
	scanf(" %[^\n]s",e1.tech_area);
	
	printf("enter project info of Employee: ");
	scanf(" %[^\n]s",e1.project_info);
	
	add_to_db(e1);
	}
	
/**************************************************************************************************************************
Function Name:void add_email(void)
Description:It is used to add email id of employee .
****************************************************************************************************************************/
void  email(){
	struct employee e1={0};
	int a=0;
	while(1)
	{
	   if(e1.emp_email_id[0]!='@'&& strchr(e1.emp_email_id,'@'))
	   {
		break;
			
	   }
	   
	   else {
			printf("enter Email ID: ");
			scanf(" %[^\n]s",e1.emp_email_id);
			//printf("Enter a valid Email-id\n");
			a++;
			
			if(a==3){

				printf(" 3 attempts completed\n");
				
				break;
			}
				continue;
		}
		
	}
}
	
	