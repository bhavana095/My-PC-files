/*******************************************************************************************************************************
Name of the module		: main.h
Date of creation 		: 3/7/2020 
Author of module 		: Komal Bankar

Description of module-
This module contains all the declarations of  functions which is defined in main.c.
 

Revision/modification History
Added  		 main.h 		Komal Bankar		3-07-2020
**********************************************************************************************************************************/

#ifndef __main_h__
#define __main_h__


void main_component(void);
void print_main_menu(void);
void print_add_menu(void);
void print_view_menu(void);
void print_modify_menu(void);
void print_delete_menu(void);
void add_component(void);
void modify_component(void);
void delete_component(void);
void view_component(void);

#endif