/*****************************************************************************************************************************
Name of the module	:TSIndia.c
Date of creation	:7/7/2020 
Author of module	:Komal Bankar.

Description of module:
This module contains the main()function required to run Reporting Structure,reads the data from the "TSIndia_EMP_DB.csv" file 
and Writes the Data on to the Excel file.

Revision/Modification History:
Added 		TSIndia.c		Komal Bankar			7-07-2020
*******************************************************************************************************************************/


#include "TSIndia.h"

/**************************************************************************************************************************
Function Name:int main(void);
Description:This is the main function.It calls the read_file_db() function to read the data from excel file.and write_file_db()
function to write data back to excel file.and also call the main_component()function.
****************************************************************************************************************************/

int main()
{

	FILE * ifp=NULL;
	FILE * ofp=NULL;


////////////////reading from excel file////////////////
	ifp=fopen("TSIndia_EMP_DB.csv","r");
	if(!ifp)
	{
		printf("Error in opening file");
		return 0;
	}
	read_file_db(ifp);
	fclose(ifp);
	
    
   
     main_component();

	
////////////////writing to excel file//////////////
ofp=fopen("TSIndia.csv","w");
	if(!ofp)
	{
		printf("Error in Writting to file ");
		return 0;
	}
	write_file_db(ofp);	
	printf("Excel sheet updated as TSIndia.csv");
fclose(ofp);

}