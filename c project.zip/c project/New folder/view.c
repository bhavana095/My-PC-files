/*********************************************************************
Name of the module	:view.c
Date of creation	:03/07/2020
Author of module	:Bhavana Srimayi Gudipati
Description of module:
This module contains function definition of view Component.




Revision/Modification History:
Added 		view.c 		G.Bhavana Srimayi			03-07-2020
**************************************************************************/

#include"TSIndia.h"

/**************************************************************************************************************************
Function Name:void view_details(void);
Description:It is used to view status of employee if its existing or not.
****************************************************************************************************************************/

void view_details(){
	struct employee e1={0};
	struct date d1={0};
	printf("enter Employee ID: ");
	scanf("%d",&e1.emp_id);
	struct node *ptr=search_details(e1.emp_id);
	if(ptr!=NULL)
	{
	
		if(ptr->data.emp_doe.date==0){
			printf("Existing Employee\n");
			printf("Employee name: %s\n",ptr->data.emp_name);
			printf("Employee Email Id: %s\n",ptr->data.emp_email_id);
			printf("Employee Band: %s\n",ptr->data.band);
			printf("Employee date of Joining: %d %d %d\n",ptr->data.emp_doj.date,ptr->data.emp_doj.month,ptr->data.emp_doj.year);
			printf("Employee Phone Number: %s\n",ptr->data.ph_no);
			printf("Manager Name: %s\n",ptr->data.manager_name);
			printf("Employee Tech Area: %s\n",ptr->data.tech_area);
			printf("Project Info of Employee: %s\n",ptr->data.project_info);
		}
		else
			printf("Employee doesn't Exist\n");
	}
	else
	{
		printf("No Data Available- Database is Empty\n");
	}
	
}
	