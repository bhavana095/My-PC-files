/*********************************************************************
Name of the module	:delete.c
Date of creation	:06-07-2020
Author of module	:Sreekesh Kulakarni
Description of module:
This module contains all the functions that are used in delete Component.

Different function supported in the module:
void delete_details(void);      Function to delete the details of employee.
int date(int,int,int);          It returns the valid date.
Revision/Modification History:
Added 		delete.c 		Sreekesh Kulakarni			06-07-2020
**************************************************************************/

#include"TSIndia.h"

/**************************************************************************************************************************
Function Name:void delete_details(void);
Description:It is used to delete the details of employee.
****************************************************************************************************************************/

void delete_details()
{
	int emp_id=0;
	struct node *ptr=NULL;
	char opt='0';
	int date=0,month=0,year=0,valid=0;
	printf("Enter the Employee id:");
	scanf("%d",&emp_id);
	fflush(stdin);
	ptr=search_details(emp_id);
	if(ptr==NULL)
	{
		printf("Employee doesnot exists \n");
		return ;
	}
	if(emp_id==ptr->data.emp_id)
	{
	while(1)
	{
	printf("enter Date of exit\n");
	printf(" enter date(dd): \n");
	scanf("%d",&date);
	printf("enter month(mm): \n");
	scanf("%d",&month);
	printf("enter year(yyyy): \n");
	scanf("%d",&year);
    valid=check_date(date,month,year);
	if(valid==0)
	{
		printf("Entered date is Invalid\n");
		continue;
	
	}
	else
	{
		ptr->data.emp_doe.date=date;
		ptr->data.emp_doe.month=month;
		ptr->data.emp_doe.year=year;
		break;
	}
	}
	}
	else
	printf("Enter Employee Id is invalid.Enter a valid one");
}

/**************************************************************************************************************************
Function Name:int check_date(int,int,int);
Description:It comes into play when user enters the Date of exit.It Checks whether the date entered is valid
****************************************************************************************************************************/
int check_date(int day,int month,int year)
{
	int is_leap=0,valid=1;
	if(year>=1900 && year<9999)
	{
		if((year%4==0 && year%100==0)||(year%400==0))
		is_leap=1;
		if(month>=1 && month<=12)
		{
			if(month==2)
			{
				 if (is_leap && day == 29) 
                		{		
                    			valid = 1;
                		}
                		else if (day > 28) 
                		{
                    			valid = 0;
                		}
			}
			else if(month==4||month==6||month==9||month==11)
			{
				if(day>30)
				{
					valid=0;
				}
			}
			else if(day>31)
			{
				valid=0;
			}
			
		}
		else
		{
			valid=0;
		}		
	}
	else
	{
		valid=0;
	}

return valid;
}
