#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/shm.h>

struct shm_attr desd_shm_attr;
unsigned char buff[64];
int prio;

int main()
{
	shmd_t desd_shm_desc;
	desd_shm_attr.shm_flags=0;
	desd_shm_attr.shm_maxmsg=4;
	desd_shm_attr.shm_msgsize=64;
	desd_shm_attr.shm_curmsgs=0;
	desd_shm_desc=shm_open("/desdmq",O_CREAT|O_RDONLY,S_IRUSR|S_IWUSR,&desd_shm_attr);

	if(desd_shm_desc==-1)
	{
		perror("error opening shared memory\n");
		return EXIT_FAILURE;
	}

	shm_receive(desd_shm_desc,buff,64,&prio);
	printf("received:%s\n",buff);
	
	shm_close(desd_shm_desc);
return EXIT_SUCCESS;
}