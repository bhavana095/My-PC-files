#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<mqueue.h>

struct mq_attr desd_mq_attr;

int main()
{
	mqd_t desd_mq_desc;
	desd_mq_attr.mq_flags=0;
	desd_mq_attr.mq_maxmsg=4;
	desd_mq_attr.mq_msgsize=64;
	desd_mq_attr.mq_curmsgs=0;
	desd_mq_desc=mq_open("/desdmq",O_CREAT|O_WRONLY,S_IRUSR|S_IWUSR,&desd_mq_attr);

	if(-1==desd_mq_desc)
	{
		perror("error opening msgqueue\n");
		return EXIT_FAILURE;
	}

	mq_send(desd_mq_desc,"hello\n",6,0);
	
	mq_close(desd_mq_desc);
return EXIT_SUCCESS;
}
