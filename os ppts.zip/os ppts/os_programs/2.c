#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/shm.h>

struct shm_attr desd_shm_attr;

int main()
{
	shmd_t desd_shm_desc;
	desd_shm_attr.mq_flags=0;
	desd_shm_attr.mq_maxmsg=4;
	desd_shm_attr.mq_msgsize=64;
	desd_shm_attr.mq_curmsgs=0;
	desd_shm_desc=mq_open("/desdmq",O_CREAT|O_WRONLY,S_IRUSR|S_IWUSR,&desd_shm_attr);

	if(-1==desd_shm_desc)
	{
		perror("error opening shared memory\n");
		return EXIT_FAILURE;
	}

	shm_send(desd_shm_desc,"hello\n",6,0);
	
	shm_close(desd_shm_desc);
return EXIT_SUCCESS;
}
